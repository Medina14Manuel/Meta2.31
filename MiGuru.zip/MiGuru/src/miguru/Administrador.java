/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package miguru;

public class Administrador extends Usuario{
    public Administrador(String Nombre, String Mail, String Contra, String Rol){
        super(Nombre,Mail,Contra,Rol);
    }  
}
