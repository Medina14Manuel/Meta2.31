/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package miguru;

/**
 *
 * @author Usuario
 */
public class MiGuru {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Usuario user = new Usuario("Medina", "Mamelogmail", "Mamelo", "Naco");
        user.IniciarSesion();
    }
    
}
